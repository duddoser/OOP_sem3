﻿using namespace std;

#include <deque>
#include <iostream>

int main()
{
	deque<int> D;
	int i = 0;
	for (i = 0; i < 10; i++)
	{
		D.push_back(i);
	}
	for (i = 0; i < 10; i++)
	{
		D.push_front(i + 10);
	}
	cout << "\n";
	for (i = 0; i < 20; i++)
	{
		cout << D[i] << " ";
	}
	cout << "\n";

	return 0;
}