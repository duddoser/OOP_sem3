﻿


using namespace std;

#include <list>
#include <vector>
#include <map>
#include <set>
#include <iostream>
#include <algorithm>
#include <iterator>

int main()
{
	//использование итераторов - интерфейс обычных двунаправленных итераторов устроен одинаков для разных контейнеров
	vector<int> v;
	int i = 0;
	for (i = 0; i < 10; i++)
	{
		v.push_back(i + 1);
	}
	cout << "\nVector:\n";
	//итератор пробегает по вектору
	vector<int>::iterator it_v = v.begin();
	while (it_v != v.end())
	{
		cout << *it_v << " ";
		it_v++;
	}

	list<char> lst;
	for (i = 0; i < 10; i++)
		lst.push_back('A' + i);

	cout << "\nList:\n";
	//итератор пробегает по списку
	list<char>::iterator it_l = lst.begin();
	while (it_l != lst.end())
	{
		//перемещение по списку с помощью итератора, нет операции [i]
		cout << *it_l << " ";
		it_l++;
	}

	//красно-черное (сблансированное) дерево map, есть интерфейс доступа к значению по ключу
	map<string, int> marks;
	marks["Petrov"] = 5;
	marks["Ivanov"] = 4;
	marks["Sidorov"] = 5;
	marks["Nikolaev"] = 3;
	marks["Abramov"] = 4;
	marks["Fedorov"] = 5;
	marks["Kuznetsov"] = 4;

	cout << "\nMap:\n";
	//итератор пробегает по map
	map<string, int>::iterator it_m = marks.begin();
	while (it_m != marks.end())
	{
		//перемещение по списку с помощью итератора, нет операции [i]
		cout << "Key: " << it_m->first << ", value: " << it_m->second << "\n";
		it_m++;
	}

	set<string> various_values;
	various_values.insert("test1");
	various_values.insert("test2");
	various_values.insert("test1");
	various_values.insert("test2");
	various_values.insert("test3");
	various_values.insert("test4");
	various_values.insert("test3");

	cout << "\nSet:\n";
	//итератор пробегает по set (сбалансированному дереву / множеству)
	set<string>::iterator it_s = various_values.begin();
	while (it_s != various_values.end())
	{
		//перемещение по списку с помощью итератора, нет операции [i]
		cout << *it_s << " ";
		it_s++;
	}


	cout << "\nVector from end:\n";
	//бег с конца
	for (it_v = v.end() - 1; it_v > v.begin(); it_v--) {
		cout << *it_v << " ";
	}
	cout << *it_v << " ";

	it_v = v.begin();
	cout << "\n*(it_v+5) = " << *(it_v + 5);

	//вывод с помощью итератора вывода
	cout << "\nOutput iterator:\n";
	copy(v.begin(), v.end(), ostream_iterator<int>(cout, " "));

	//вставка с помощью итератора вставки
	//вставка в голову
	char Arr[] = { 'a', 'b', 'c' };
	copy(Arr, Arr + 3, front_inserter(lst)); //вставляем в голову списка lst элементы массива Arr
	cout << "\nList after insertion with iterators:\n";
	copy(lst.begin(), lst.end(), ostream_iterator<char>(cout, " ")); //выводим список на экран

	char Arr2[] = { 'x', 'y', 'z' };
	copy(Arr2, Arr2 + 3, back_inserter(lst)); //вставляем в голову списка lst элементы массива Arr
	cout << "\nList after insertion with iterators:\n";
	copy(lst.begin(), lst.end(), ostream_iterator<char>(cout, " ")); //выводим список на экран

	cout << "\nReverse iterator:\n";
	//реверсивный итератор пробегает по списку
	list<char>::reverse_iterator itr_l = lst.rbegin();
	while (itr_l != lst.rend())
	{
		//перемещение по списку с помощью итератора, нет операции [i]
		cout << *itr_l << "";
		itr_l++;
	}

	char c; cin >> c;
	return 0;
}