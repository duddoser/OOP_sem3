﻿

using namespace std;

#include <list>
#include <algorithm>
#include <iostream>


char CaesarForward(char c)
{
	if (c == 'z')
		return 'a';
	if (c == 'Z')
		return 'A';
	c++;
	return c;
}

char CaesarBackward(char c)
{
	if (c == 'a')
		return 'z';
	if (c == 'A')
		return 'Z';
	c--;
	return c;
}

int main()
{
	list<char> lst;
	lst.push_back('t');
	lst.push_back('e');
	lst.push_back('s');
	lst.push_back('t');
	lst.push_back('s');
	lst.push_back('t');
	lst.push_back('r');
	lst.push_back('i');
	lst.push_back('n');
	lst.push_back('g');

	list<char>::iterator p = lst.begin();
	while (p != lst.end())
	{
		//перемещение по контейнеру с помощью итератора
		cout << *p << "";
		p++;
	}
	
	//алгоритм transform - применить ко всем элементам списка функцию CaesarForward
	transform(lst.begin(), lst.end(), lst.begin(), CaesarForward);

	cout << "\nCaesar coding: ";
	p = lst.begin();
	while(p!=lst.end())
	{
		cout<<*p<<"";
		p++;
	}
	cout<<"\nCaesar decoding: ";

	//алгоритм transform - применить ко всем элементам списка функцию CaesarBackward
	transform(lst.begin(), lst.end(), lst.begin(), CaesarBackward);

	p = lst.begin();
	while(p!=lst.end())
	{
		cout<<*p<<"";
		p++;
	}
	cout<<"\n";
	
	char c; cin>>c;
	return 0;
}
