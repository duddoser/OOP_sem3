﻿


using namespace std;

#include <list>
#include <algorithm>
#include <iostream>

bool compare_chars(char c1, char c2)
{
	int coord1, coord2;

	if ('a' <= c1 && c1 <= 'z')
		coord1 = c1 - 'a';
	else
		coord1 = c1 - 'A';

	if ('a' <= c2 && c2 <= 'z')
		coord2 = c2 - 'a';
	else
		coord2 = c2 - 'A';

	return coord1 < coord2;
}



int main()
{
	list<char> lst;
	int i = 0;
	for (i = 0; i < 10; i++)
		lst.push_back('A' + i);

	for (i = 0; i < 10; i++)
		lst.push_back('a' + i);

	//обычная сортировка
	//lst.sort();

	//сортировка с переопределением функции сравнения элементов
	lst.sort(compare_chars);

	list<char>::iterator p = lst.begin();
	while (p != lst.end())
	{
		//перемещение по контейнеру с помощью итератора
		cout << *p << "";
		p++;
	}

	char c; cin >> c;
	return 0;
}
