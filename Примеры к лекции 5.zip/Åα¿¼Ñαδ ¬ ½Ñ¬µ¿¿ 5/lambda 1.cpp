﻿

using namespace std;

#include <algorithm>
#include <array>
#include <iostream>

int main()
{
	std::array<std::string, 4> arr{ "apple", "banana", "walnut", "lemon" };

	// Определяем функцию непосредственно в том месте, где собираемся её использовать
	auto found{ std::find_if(arr.begin(), arr.end(),
							 [](std::string str) // вот наша лямбда, без поля captureClause
							 {
							   return (str.find("nut") != std::string::npos);
							 }) };

	if (found == arr.end())
	{
		std::cout << "No nuts\n";
	}
	else
	{
		std::cout << "Found " << *found << '\n';
	}

	char c; cin >> c;
	return 0;
}