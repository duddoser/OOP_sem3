﻿

using namespace std;
#include <iostream>
#include <functional>

int main() {

	

	auto lambda_fun1 = [] {};     //Запомнили лямбда-функцию в объект
	auto lambda_fun2 = [] { return 200; };    //Запомнили лямбда-функцию в объект

	auto hello_world1 = [] { cout << "hello"; };
	auto hello_world2 = [](const char* S) { cout << S; };

	//вызываем лямбда-функции с помощью объектов-хранителей
	lambda_fun1();        //пустая, ничего не произойдёт
	lambda_fun2();        //ничего не произойдёт
	cout << lambda_fun2() << '\n'; //выведет на экран 200

	cout << '\n';
	hello_world1();      //выведет на экран "hello"

	cout << '\n';
	hello_world2("hi-hi-hi");      //выведет на экран "hi-hi-hi"

	char c; cin >> c;
	return 0;
}