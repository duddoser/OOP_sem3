﻿

using namespace std;

#include <iostream>
int main()
{
	int ammo{ 10 };

	// Определяем лямбду внутри переменной с именем shoot
	auto shoot{
	  [ammo]() {
		// Запрещено, так как переменная ammo была захвачена в виде константной копии
		--ammo;

		std::cout << "Pew! " << ammo << " shot(s) left.\n";
	  }
	};

	// Вызов лямбды
	shoot();

	std::cout << ammo << " shot(s) left\n";

	return 0;
}