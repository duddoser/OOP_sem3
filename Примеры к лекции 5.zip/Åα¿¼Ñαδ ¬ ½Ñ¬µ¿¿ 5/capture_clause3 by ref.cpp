﻿

using namespace std;
#include <iostream>

int main()
{
	int ammo{ 10 };

	auto shoot{
		// Ключевое слово mutable теперь нам не потребуется
		[&ammo]() { // &ammo означает, что переменная ammo захватывается по ссылке
		  // Изменения текущей переменной ammo приведут к изменению переменной ammo из блока main()
		  --ammo;

		  std::cout << "Pew! " << ammo << " shot(s) left.\n";
		}
	};

	shoot();

	std::cout << ammo << " shot(s) left\n";

	return 0;
}