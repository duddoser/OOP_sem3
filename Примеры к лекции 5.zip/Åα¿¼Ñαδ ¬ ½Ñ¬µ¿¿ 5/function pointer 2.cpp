﻿

using namespace std;
#include <iostream>
#include <functional>

void foo(function<double()> ptr) 
{      
	//Создали функцию для приёма лямбда-функции
	cout << ptr() << '\n';      //приняли лямбда-функцию в ptr и используем её
}

int main() {

	auto lambda_fun = []()->double 
	{
		return 200.5;
	};


	foo(lambda_fun);
	char c; cin >> c;
	return 0;
}