﻿using namespace std;

#include <algorithm>
#include <iostream>
#include <list>



using namespace std;

#include <list>
#include <algorithm>
#include <iostream>

bool glas(char c)
{
	char c1 = tolower(c);
	if (c1 == 'a' || c1 == 'e' || c1 == 'i' || c1 == 'o' || c1 == 'u' || c1 == 'y')
		return true;
	return false;
}

int main()
{
	list<char> lst;
	lst.push_back('t');
	lst.push_back('e');
	lst.push_back('s');
	lst.push_back('t');
	lst.push_back('s');
	lst.push_back('t');
	lst.push_back('r');
	lst.push_back('i');
	lst.push_back('n');
	lst.push_back('g');

	list<char>::iterator p = lst.begin();
	while (p != lst.end())
	{
		//перемещение по контейнеру с помощью итератора
		cout << *p << "";
		p++;
	}

	//алгоритмы count, count_if  - подсчёт числа элементов в контейнере, совпадающих с переданным, или тех, для которых функция glas вернёт true
	int n1 = count(lst.begin(), lst.end(), 's');
	int n2 = count_if(lst.begin(), lst.end(), glas);

	cout << "\nNumber of 's': " << n1 << ", vowels: " << n2;

	char c; cin >> c;
	return 0;
}

