﻿

using namespace std;
#include <iostream>

int main() {

	int x = 10;
	double y = 5.5;

	[&]() { x++, y = y + 10; }();        //захват всех значений по ссылке из текущей области видимости

	cout << "x == " << x << '\n';        //11
	cout << "y == " << y << '\n';        //15.5
}