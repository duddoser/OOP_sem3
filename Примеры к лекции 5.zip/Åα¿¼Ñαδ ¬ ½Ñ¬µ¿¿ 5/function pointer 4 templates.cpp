﻿

using namespace std;
#include <iostream>
#include <functional>

template <typename T>
void foo(T ptr) {                    //Тип автоматически подставится
	cout << ptr(0, "") << '\n';
}

int main() {

	auto lambda_fun = [](int x, string S)->double {   //1. у лямбда-функции появились параметры
		return 200.5;
	};


	foo(lambda_fun);
}