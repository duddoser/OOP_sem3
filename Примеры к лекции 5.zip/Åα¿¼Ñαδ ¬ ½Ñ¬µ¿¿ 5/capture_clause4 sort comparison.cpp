﻿

using namespace std;

#include <algorithm>
#include <array>
#include <iostream>
#include <string>

struct Car
{
	std::string make{};
	std::string model{};
};

int main()
{
	std::array<Car, 3> cars{ { { "Volkswagen", "Golf" },
							   { "Toyota", "Corolla" },
							   { "Honda", "Civic" } } };

	int comparisons{ 0 };

	std::sort(cars.begin(), cars.end(),
		// Захват переменной comparisons по ссылке
		[&comparisons](const auto& a, const auto& b) {
			// Мы захватили переменную comparisons по ссылке, а это означает, что мы можем изменять её без использования спецификатора mutable
			++comparisons;

			// Сортировка машин по марке
			return (a.make < b.make);
		});

	std::cout << "Comparisons: " << comparisons << '\n';

	for (const auto& car : cars)
	{
		std::cout << car.make << ' ' << car.model << '\n';
	}

	return 0;
}