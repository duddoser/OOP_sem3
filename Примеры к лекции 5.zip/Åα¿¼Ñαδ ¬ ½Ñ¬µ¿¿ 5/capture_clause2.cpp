﻿

using namespace std;

#include <iostream>

int main()
{
	int ammo{ 10 };

	auto shoot{
		// Добавляем ключевое слово mutable после списка параметров
		[ammo]() mutable {
		// Теперь нам разрешено изменять значение переменной ammo
		--ammo;

		std::cout << "Pew! " << ammo << " shot(s) left.\n";
	  }
	};

	shoot();
	shoot();

	std::cout << ammo << " shot(s) left\n";

	return 0;
}