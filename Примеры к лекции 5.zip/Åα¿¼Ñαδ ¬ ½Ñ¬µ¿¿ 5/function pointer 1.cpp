﻿

using namespace std;
#include <iostream>
#include <functional>

void foo(double (*ptr)()) {      //Создали функцию для приёма лямбда-функции
	cout << ptr() << '\n';      //приняли лямбда-функцию в ptr и используем её
}

int main() {

	auto lambda_fun = []()->double {		//явно указываем, что возвращаемый тип будет double
		int x = 10;
		if (x == 10) return 5;
		else return 1.6;        //теперь всё ОК
	};


	foo(lambda_fun);

	char c; cin >> c;
	return 0;
}