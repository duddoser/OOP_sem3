﻿

using namespace std;
#include <iostream>
#include <functional>

void foo(function<double(int, string)> ptr) {      //2. Типы этих параметров указываются в круглых скобках
	cout << ptr(0, "") << '\n';      //3. Вызываем нашу лямбда-функцию,не забываем, что она сейчас с параметрами
}

int main() {

	auto lambda_fun = [](int x, string S)->double {   //1. у лямбда-функции появились параметры
		return 200.5;
	};


	foo(lambda_fun);
}