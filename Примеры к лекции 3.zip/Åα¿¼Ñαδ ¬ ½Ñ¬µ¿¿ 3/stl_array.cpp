﻿using namespace std;

#include<iostream>

#include <array>
#include <iostream>

int main()
{
	array<int, 4> c0 = { 0, 1, 2, 3 };

	// display contents " 0 1 2 3"
	for (const auto& it : c0)
	{
		std::cout << " " << it;
	}
	std::cout << std::endl;

	array<int, 4> c1(c0);

	// display contents " 0 1 2 3"
	for (const auto& it : c1)
	{
		std::cout << " " << it;
	}
	std::cout << std::endl;

	// display contents " 0 1 2 3"
	for (int i = 0; i < 4; i++)
	{
		std::cout << c1[i] << " ";
	}
	std::cout << std::endl;

	return (0);
}