﻿

using namespace std;

#include <set>
#include <iostream>

int main() {
	// Объявление множества:
	// set<type>, где type - тип элементов.
	set<int> s;

	int n, x;
	cout << "\n Quantity of elements: ";
	cin >> n;
	cout << "\n Elements: ";
	for (int i = 0; i < n; i++) {
		cin >> x;
		// Вставка элементов массива во множество.
		s.insert(x);
	}
	// Вывод размера множества,
	// т.е. количества различных элементов в нем.
	cout <<"\nThere are "<< s.size()<<" different elements";
}