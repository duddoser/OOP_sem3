﻿using namespace std;

#include <map>
#include <iostream>

int main()
{
	//усложненное сбалансированное дерево map
//на первом месте - ключ, на втором - хранимое значение (поле, данные)
	map<string, int> marks;

	marks.insert(std::pair<string, int>("peter", 4));
	marks.insert(std::pair<string, int>("ivan", 5));
	marks.insert(std::pair<string, int>("alex", 3));
	marks.insert(std::pair<string, int>("igor", 3));

	marks["peter"] = 3;


	map<string, int>::iterator it = marks.begin();

	//поиск стоит O(log n), т.к. в основе дерево
	//при использовании хэширования затратим O(1), но расплатимся дополнительной памятью
	map<string, int>::iterator it_f = marks.find("peter");

	cout<<"\nFound: " << (*it_f).first << ": " << (*it_f).second << endl;

	//при перечислении дерева получим элементы в InOrder-обходе - в порядке возрастания
	for (; it != marks.end(); it++)
	{
		cout << (*it).first << ": " << (*it).second << endl;
	}
	cout << "\n";

	return 0;
}